<?php
require_once "admin/Modelo/connectionPDO.php";
require_once "Vista/content/crearHeader.php";
require_once "Vista/content/crearFooter.php";

crearHeader();

$vista = null;
if (isset($_REQUEST['vista'])) {
	$vista = $_REQUEST['vista'];
}

if ($vista == "Buscar") {

	require_once "admin/Modelo/ingredientes_recetaPDO.php";
	require_once "admin/Modelo/ingredientePDO.php";
	require_once "Vista/vistaBuscarReceta.php";

	//Busqueda de recetas
	$listaR = ingredientes_recetaPDO::verRecetas_conIngredientes($_REQUEST['ingredientes']);
	$ingrBusqueda = [];
	$link = "";
	foreach ($_REQUEST['ingredientes'] as $key => $value) {
		$registro = ingredientePDO::verIngrediente($value);
		$ingrBusqueda[] = $registro['nombre'];
		if ($key == count($_REQUEST['ingredientes']) - 1) {
			$link .= "bus[]=$value";
		} else {
			$link .= "bus[]=$value&";
		}

	}

	crearVistaBuscarReceta($listaR, $ingrBusqueda, $link);

} else if ($vista == "Receta") {
	require_once "admin/Modelo/ingredientes_recetaPDO.php";
	require_once "admin/Modelo/recetaPDO.php";
	require_once "Vista/vistaRecetaCliente.php";

	//buscar receta para visualizar
	$codigo = $_REQUEST['mostrar_receta'];
	$datos = recetaPDO::verReceta($codigo);
	$ingredientes = ingredientes_recetaPDO::verIngredientes_receta($codigo);
	$linkAtras = "";
	foreach ($_REQUEST['bus'] as $key => $value) {
		if ($key == count($_REQUEST['bus']) - 1) {
			$linkAtras .= "ingredientes[]=$value";
		} else {
			$linkAtras .= "ingredientes[]=$value&";
		}
	}

	crearVistaRecetaCliente($datos, $ingredientes, $linkAtras);

} else {
	//Vista inicial
	require_once "admin/Modelo/ingredientePDO.php";
	require_once "Vista/vistaSelIngrediente.php";

	$listaIng = ingredientePDO::verIngredientes();
	crearVistaSelIngrediente($listaIng);

}

crearFooter();

?>