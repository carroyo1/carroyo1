<?php function crearVistaSelIngrediente($listaIng) {
	?>

<main>

	<section id="cont-form-selIngr">

		<script type="text/javascript"  src="Vista/js/gestionSelReceta.js"></script>

		<form action="/Suete" method="get" id="form-selIngr">
			<div id="cont-btBuscar">
				<input type="submit" name="vista" value="Buscar" id="btBuscar" disabled>
				<input type="reset" value="Restablecer" id="btReset">
			</div>

			<?php foreach ($listaIng as $key => $value) {?>

				<div id="<?php echo "cont-ingr-$key" ?>" class="cont-ingr">
					<input type="checkbox" value="<?php echo $value['codI'] ?>" name="ingredientes[]" id="<?php echo "check-ingr-$key" ?>" class="check-ingr">
					<label class="label-ingr" for="<?php echo "check-ingr-$key" ?>">
						<figure>
							<img src="<?php echo "$value[imagen]"; ?>" alt="<?php echo "$value[nombre]"; ?>" class="form-selIng-img">
						</figure>
						<figcaption>
							<?php echo $value['nombre'] ?>
						</figcaption>

					</label>
				</div>

			<?php }?>


		</form>

	</section>

</main>


<?php }?>