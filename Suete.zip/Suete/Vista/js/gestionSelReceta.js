document.addEventListener('DOMContentLoaded', function() {

    $(".check-ingr").change(function() {

        if (this.checked) {
            $("#btBuscar").removeAttr("disabled");
        } else {
            var checks = document.getElementsByClassName("check-ingr");
            var existe = false;

            for (var i = 0; i < checks.length && !existe; i++) {
                if (checks[i].checked) {
                    existe = true;
                }
            }

            if (!existe) {
                $("#btBuscar").attr("disabled", true);
            }
            
        }

    });

    $("#btReset").click(function(){
        $("#btBuscar").attr("disabled", true);
    });

});