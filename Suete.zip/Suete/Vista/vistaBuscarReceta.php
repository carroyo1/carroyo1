<?php function crearVistaBuscarReceta($listaR, $ingrBusqueda, $link) {
	?>

<main>
	<section id="cont-busq-receta">

		<a href="/Suete" class="volver"><span>&#8592</span> Volver</a>

		<h2 style="text-align: center; margin: 1vh 0;">Resultados de la Busqueda: </h2>

		<div class="cont-ingredientes-seleccionados">

			<ul class="lista-ingredientes">
				<strong>Ingredientes seleccionados: </strong>

				<?php foreach ($ingrBusqueda as $key => $value) {?>
					<li>
						<span>
							<?php echo $value; ?>
						</span>
					</li>
				<?php }?>

			</ul>

		</div>

		<?php foreach ($listaR as $i => $receta) {?>

			<article class="cont-receta" id="<?php echo "cont-receta$i" ?>">

				<a href="/Suete?vista=Receta&mostrar_receta=<?php echo $receta['codR'] ?>&<?php echo $link ?>">
					<figure>
						<img src="<?php echo $receta['imagen'] ?>" alt="<?php echo $receta['nombre'] ?>">
					</figure>
					<h3><?php echo $receta['nombre'] ?></h3>
				</a>

			</article>

		<?php }?>

		<?php if (!$listaR) {?>

			<h4 class="no-hay-resultados">No se encontraron resultados</h4>

		<?php }?>

	</section>
</main>

<?php }?>
