<?php function crearVistaRecetaCliente($datos, $ingredientes, $linkAtras) {?>

<main>

	<a href="/Suete?vista=Buscar&<?php echo $linkAtras ?>" class="volver"><span>&#8592</span> Volver</a>

	<article id="container-cuerpo-receta">
		<h2><?php echo $datos["nombre"] ?></h2>
		<div id="cont-imagen">
			<img src="<?php echo $datos["imagen"] ?>" alt="<?php echo $datos["nombre"] ?>">
		</div>
		<div id="cont-ingredientes">
			<h4>Ingredientes</h4>
			<ul class="listIngredientes">

				<?php foreach ($ingredientes as $value) {?>

					<li>
						<span class="cont-ingr">
							<figure><img src="<?php echo $value['imagen'] ?>" alt="<?php echo $value['nombre'] ?>"></figure>
							<span class="nombre"><?php echo $value['nombre'] . ": " ?></span>
							<span class="cantidad"><?php echo $value['cantidad'] ?></span>
						</span>
					</li>

				<?php }?>

			</ul>
		</div>
		<div id="cont-descripcion">
		<h4>Descripción</h4>
			<div><?php echo $datos["descripcion"] ?></div>
		</div>
		<div id="cont-como-se-hace">
			<h4>Como se hace</h4>
			<div><?php echo $datos["como_se_hace"] ?></div>
		</div>
	</article>

</main>

<?php }?>