<?php function crearHeader() {
	?>
	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Suete</title>
		<link rel="shortcut icon" href="Vista/img/logo.png"/>
		<link rel="stylesheet" href="Vista/css/style.css">
		<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
	</head>
	<body>
	<header>
		<a href="/suete">
			<figure id="cont-logo-suete">
				<img src="Vista/img/logo.png" alt="Suete">
			</figure>
		</a>
	</header>
<?php }?>