<?php function crearFooter() {
	?>
<footer>
	<div class="marca">
		<span>© Suete <?php echo date('Y') ?>. Todos los derechos reservados.</span>
	</div>
	<nav class="social">
		<h4>Siguenos:</h4>
		<ul>
			<li>
				<a href="https://twitter.com/explore">
					<img src="Vista/img/twitter.svg" alt="Twitter">
				</a>
			</li>
			<li>
				<a href="https://es-es.facebook.com">
					<img src="Vista/img/facebook.svg" alt="Facebook">
				</a>
			</li>
			<li>
				<a href="https://www.instagram.com/?hl=es">
					<img src="Vista/img/instagram.svg" alt="Instagram">
				</a>
			</li>
			<li class="ref-designer">
				<div>Iconos diseñados por <a href="https://www.flaticon.es/autores/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.es/" title="Flaticon">www.flaticon.es</a></div>
			</li>
		</ul>
	</nav>
</footer>
</body>
</html>
<?php }?>