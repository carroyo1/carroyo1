<?php
/**
 *
 */
class ingredientePDO {

	function __construct() {
		# code...
	}

	public static function crearIngrediente($datos) {

		$conexion = ConnectionPDO::getConexion();

		$sql = "INSERT INTO `ingrediente` (`codI`, `nombre`, `imagen`) VALUES (:nuevoCodI, :nombre, :imagen)";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(":nuevoCodI", $datos['nuevoCodI'], PDO::PARAM_INT);
		$stmt->bindParam(":nombre", $datos['nombre'], PDO::PARAM_STR);
		$stmt->bindParam(":imagen", $datos['imagen'], PDO::PARAM_STR);
		$ok = $stmt->execute();
		ConnectionPDO::closeConexion();

		return $ok;

	}

	public static function verIngrediente($codI) {
		$conexion = ConnectionPDO::getReadConexion();
		$sql = "SELECT * FROM `ingrediente` WHERE codI = ?";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(1, $codI, PDO::PARAM_INT);
		$stmt->execute();
		$datos = $stmt->fetch();
		ConnectionPDO::closeConexion();
		return $datos;
	}

	public static function verIngredientes($orden = "Abc") {
		$conexion = ConnectionPDO::getReadConexion();
		$sql;
		if ($orden == "Abc") {
			$sql = "SELECT * FROM ingrediente ORDER BY `nombre` ASC";
		} else {
			$sql = "SELECT * FROM ingrediente ORDER BY `codI` ASC";
		}
		$stmt = $conexion->query($sql);
		$ingredientes;
		while ($datos = $stmt->fetch()) {
			$ingredientes[] = $datos;
		};
		ConnectionPDO::closeConexion();
		return $ingredientes;
	}

	public static function actualizarIngrediente($codI, $datos) {

		$conexion = ConnectionPDO::getConexion();

		$sql = "UPDATE `ingrediente` SET `codI` = :nuevoCodI , `nombre` = :nombre, `imagen` = :imagen WHERE `ingrediente`.`codI` = :codI";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(":nuevoCodI", $datos['nuevoCodI'], PDO::PARAM_INT);
		$stmt->bindParam(":nombre", $datos['nombre'], PDO::PARAM_STR);
		$stmt->bindParam(":imagen", $datos['imagen'], PDO::PARAM_STR);
		$stmt->bindParam(":codI", $codI, PDO::PARAM_INT);
		$ok = $stmt->execute();
		ConnectionPDO::closeConexion();

		return $ok;

	}

	public static function borrarIngrediente($codI) {

		$sql = "DELETE FROM `ingrediente` WHERE codI = ?";
		$conexion = ConnectionPDO::getConexion();
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(1, $codI, PDO::PARAM_INT);
		$ok = $stmt->execute();

		ConnectionPDO::closeConexion();
		return $ok;

	}

	public static function getAutoIncrementValueIngrediente() {

		$sql = "SELECT `AUTO_INCREMENT` FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'programa_recetas' AND TABLE_NAME = 'ingrediente'";
		$conexion = ConnectionPDO::getConexion();
		$stmt = $conexion->prepare($sql);
		$ok = $stmt->execute();

		if ($ok) {
			$valor = $stmt->fetch();
			return $valor['AUTO_INCREMENT'];
		} else {
			return "Error";
		}

		ConnectionPDO::closeConexion();

	}
}