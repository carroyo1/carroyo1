<?php
/**
 *
 */
class ingredientes_recetaPDO {

	function __construct() {
		# code...
	}
	public static function crearIngredientes_receta($datos) {

		$conexion = ConnectionPDO::getConexion();
		$sql = "INSERT INTO `ingrediente_receta` (`codI`, `codR`, `cantidad`) VALUES (?, ?, ?)";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(1, $datos['codI'], PDO::PARAM_INT);
		$stmt->bindParam(2, $datos['codR'], PDO::PARAM_INT);
		$stmt->bindParam(3, $datos['cantidadI'], PDO::PARAM_STR);
		$ok = $stmt->execute();
		ConnectionPDO::closeConexion();
		return $ok;

	}

	public static function verIngredientes_receta($codR) {
		$conexion = ConnectionPDO::getReadConexion();
		$sql = "SELECT i.*, ir.cantidad from ingrediente i, ingrediente_receta ir WHERE i.codI = ir.codI AND 	ir.codR = ?";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(1, $codR, PDO::PARAM_INT);
		$stmt->execute();
		$ingredientes = [];
		while ($registro = $stmt->fetch()) {
			$ingredientes[] = $registro;
		}

		ConnectionPDO::closeConexion();
		return $ingredientes;
	}

	public static function verRecetas_conIngredientes($arrayCodI) {
		$conexion = ConnectionPDO::getReadConexion();
		$sql = "SELECT codR, nombre, imagen FROM recetas WHERE ";

		for ($i = 0; $i < count($arrayCodI); $i++) {

			if ($i == count($arrayCodI) - 1) {
				$sql .= "codR IN (SELECT codR FROM ingrediente_receta WHERE codI = ?)";
			} else {
				$sql .= "codR IN (SELECT codR FROM ingrediente_receta WHERE codI = ?) AND ";
			}

		}

		$stmt = $conexion->prepare($sql);

		for ($i = 0; $i < count($arrayCodI); $i++) {
			$stmt->bindParam($i + 1, $arrayCodI[$i], PDO::PARAM_INT);
		}

		$stmt->execute();
		$recetas = [];
		while ($registro = $stmt->fetch()) {
			$recetas[] = $registro;
		}
		return $recetas;
	}

	public static function borrarIngredientesReceta($codR) {

		$conexion = ConnectionPDO::getConexion();
		$sql = "DELETE FROM `ingrediente_receta` WHERE `ingrediente_receta`.`codR` = ?";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(1, $codR, PDO::PARAM_INT);
		$ok = $stmt->execute();
		ConnectionPDO::closeConexion();
		return $ok;

	}
}