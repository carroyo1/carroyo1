<?php
/**
 *
 */
class recetaPDO {
	function __construct() {
		# code...
	}

	public static function crearReceta($datos) {

		$conexion = ConnectionPDO::getConexion();

		$sql = "INSERT INTO `recetas` (`codR`, `nombre`, `descripcion`, `como_se_hace`, `imagen`) VALUES (:NuevoCodR, :nombre, :descripcion, :como_se_hace, :imagen)";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(":NuevoCodR", $datos['NuevoCodR'], PDO::PARAM_INT);
		$stmt->bindParam(":nombre", $datos['nombre'], PDO::PARAM_STR);
		$stmt->bindParam(":descripcion", $datos['descripcion'], PDO::PARAM_STR);
		$stmt->bindParam(":como_se_hace", $datos['como_se_hace'], PDO::PARAM_STR);
		$stmt->bindParam(":imagen", $datos['imagen'], PDO::PARAM_STR);
		$ok = $stmt->execute();
		ConnectionPDO::closeConexion();

		return $ok;

	}

	public static function verReceta($codR) {

		$conexion = ConnectionPDO::getReadConexion();
		$sql = "SELECT * FROM `recetas` WHERE codR = ?";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(1, $codR, PDO::PARAM_INT);
		$stmt->execute();
		$datos = $stmt->fetch();
		ConnectionPDO::closeConexion();
		return $datos;

	}

	public static function verRecetas() {

		$conexion = ConnectionPDO::getReadConexion();
		$recetas = $conexion->query("SELECT * FROM recetas ORDER BY `nombre` ASC ");
		ConnectionPDO::closeConexion();
		return $recetas;
	}

	public static function actualizarReceta($codR, $datos) {

		$conexion = ConnectionPDO::getConexion();

		$sql = "UPDATE `recetas` SET codR = :NuevoCodR , `nombre` = :nombre, descripcion = :descripcion, como_se_hace = :como_se_hace, imagen = :imagen  WHERE `recetas`.`codR` = :codR; ";
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(":NuevoCodR", $datos['NuevoCodR'], PDO::PARAM_INT);
		$stmt->bindParam(":nombre", $datos['nombre'], PDO::PARAM_STR);
		$stmt->bindParam(":descripcion", $datos['descripcion'], PDO::PARAM_STR);
		$stmt->bindParam(":como_se_hace", $datos['como_se_hace'], PDO::PARAM_STR);
		$stmt->bindParam(":imagen", $datos['imagen'], PDO::PARAM_STR);
		$stmt->bindParam(":codR", $codR, PDO::PARAM_INT);
		$ok = $stmt->execute();
		ConnectionPDO::closeConexion();

		return $ok;

	}

	public static function borrarReceta($codR) {

		$sql = "DELETE FROM `recetas` WHERE `recetas`.`codR` = ?";
		$conexion = ConnectionPDO::getConexion();
		$stmt = $conexion->prepare($sql);
		$stmt->bindParam(1, $codR, PDO::PARAM_INT);
		$ok = $stmt->execute();

		ConnectionPDO::closeConexion();
		return $ok;

	}

	public static function getAutoIncrementValueRecetas() {

		$sql = "SELECT `AUTO_INCREMENT` FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'programa_recetas' AND TABLE_NAME = 'recetas'";
		$conexion = ConnectionPDO::getConexion();
		$stmt = $conexion->prepare($sql);
		$ok = $stmt->execute();

		if ($ok) {
			$valor = $stmt->fetch();
			return $valor['AUTO_INCREMENT'];
		} else {
			return "Error";
		}

		ConnectionPDO::closeConexion();

	}

}