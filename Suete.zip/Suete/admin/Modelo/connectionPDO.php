<?php
/**
 *
 */
class ConnectionPDO {
	private static $conexion;
	private static $sgbd = "mysql";
	private static $host = "localhost";
	private static $nombre_bbdd = "programa_recetas";
	private static $usuario = "root";
	private static $passwd = "";

	public function __construct() {
	}

	//Este método se usa para las sentencias para modificar métodos, es necesario iniciar sesión manualmente con tu cuenta de mysql
	public static function getConexion() {
		$usuario = $_SESSION['nombre'];
		$passwd = $_SESSION['contr'];

		$conexion = new PDO(self::$sgbd . ":host=" . self::$host . ";dbname=" . self::$nombre_bbdd . ";", $usuario, $passwd, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
		return $conexion;
	}

	//Este método es para obtener una conexión sin necesidad de introducir datos, será usado en las sentencias de lectura de datos (como en todas de la propia página)
	public static function getReadConexion() {

		$conexion = new PDO(self::$sgbd . ":host=" . self::$host . ";dbname=" . self::$nombre_bbdd . ";", self::$usuario, self::$passwd, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));

		return $conexion;
	}
	public static function closeConexion() {
		$conexion = null;
	}

}
