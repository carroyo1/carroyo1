<?php
if (isset($_REQUEST['vistaI']) && $_REQUEST['vistaI'] == "vistaI") {

	if (isset($_REQUEST['accion'])) {

		require_once "Vista/content/bannerExito.php";
		require_once "Vista/content/bannerError.php";

		function crearDatosIngrediente_fromRequest() {

			$nuevoCodI = $_REQUEST['nuevoCodI'];
			$nombre = $_REQUEST['nombre'];
			$imagen = $_REQUEST['imagen'];

			return ["nuevoCodI" => $nuevoCodI, "nombre" => $nombre, "imagen" => $imagen];

		}

		if ($_REQUEST['accion'] == "Actualizar") {

			$datos = crearDatosIngrediente_fromRequest();
			$ok = ingredientePDO::actualizarIngrediente($_REQUEST['codI'], $datos);

			if ($ok) {
				crearBannerExito("Ingrediente actualizado satisfactoriamente");
			} else {
				crearBannerError("No se pudo actualizar ingrediente");
			}

		} elseif ($_REQUEST['accion'] == "Borrar") {

			$ok = ingredientePDO::borrarIngrediente($_REQUEST['codI']);

			if ($ok) {
				crearBannerExito("Ingrediente borrado satisfactoriamente");
			} else {
				crearBannerError("No se pudo borrar ingrediente");
			}

		} elseif ($_REQUEST['accion'] == "Insertar") {

			$datos = crearDatosIngrediente_fromRequest();
			$ok = ingredientePDO::crearIngrediente($datos);

			if ($ok) {
				crearBannerExito("Ingrediente insertado satisfactoriamente");
			} else {
				crearBannerError("No se pudo insertar ingrediente");
			}
		}

	}

	if (isset($_REQUEST['nuevoI'])) {

		$codI_auto = ingredientePDO::getAutoIncrementValueIngrediente();

		require_once "Vista/vistaNuevoIngrediente.php";
		crearVistaNuevoIngrediente($codI_auto);

	} else {

		$listaIng;
		require_once "Vista/vistaIngrediente.php";

		if (isset($_REQUEST['ordenar']) && $_REQUEST['ordenar'] == "123" || isset($_REQUEST['ordenar']) && $_REQUEST['ordenar'] == "Abc") {
			$listaIng = ingredientePDO::verIngredientes($_REQUEST['ordenar']);
			crearVistaIngrediente($listaIng);

		} else {
			$listaIng = ingredientePDO::verIngredientes();
			crearVistaIngrediente($listaIng);
		}

	}
}

?>