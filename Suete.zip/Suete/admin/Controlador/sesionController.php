<?php

function comprobarSesion() {

	session_start();

	if (isset($_REQUEST['nombre']) && isset($_REQUEST['contr']) && $_REQUEST['nombre'] !== "") {
		$_SESSION['nombre'] = $_REQUEST['nombre'];
		$_SESSION['contr'] = $_REQUEST['contr'];
		try {
			ConnectionPDO::getConexion();
		} catch (PDOException $e) {
			unset($_SESSION['nombre']);
			unset($_SESSION['contr']);
		}
	}

	if (isset($_SESSION['nombre']) && isset($_SESSION['contr'])) {

		if (isset($_REQUEST['sesion']) && $_REQUEST['sesion'] == "Cerrar Sesión") {
			session_destroy();
			return false;
		} else {
			return true;
		}
	} else {
		return false;
		session_destroy();
	}

}

?>