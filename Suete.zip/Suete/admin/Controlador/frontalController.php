<?php

header('Content-Type: text/html; charset=utf-8');

require_once "Modelo/connectionPDO.php";
require_once "Controlador/sesionController.php";

if (comprobarSesion()) {

	require_once "Modelo/ingredientePDO.php";
	require_once "Modelo/recetaPDO.php";
	require_once "Modelo/ingredientes_recetaPDO.php";
	require_once "Vista/content/crearHeader.php";
	require_once "Vista/content/crearFooter.php";

	crearHeader("Vista/css/style.css");

	$accion = null;
	if (isset($_REQUEST['accion'])) {
		$accion = $_REQUEST['accion'];
		require_once "Vista/vistaError.php";
		require_once "Vista/vistaExito.php";
	}

	if (isset($_REQUEST['vistaI'])) {

		require_once "Controlador/IngredienteController.php";

	} elseif (isset($_REQUEST['nuevaR'])) {
		$codR_auto = recetaPDO::getAutoIncrementValueRecetas();
		$listIng = ingredientePDO::verIngredientes();

		require_once "Vista/vistaNuevaReceta.php";
		crearVistaNuevaReceta($codR_auto, $listIng);

	} elseif ($accion == "Borrar") {

		$ok = recetaPDO::borrarReceta($_REQUEST['codigoR']);

		if ($ok) {
			crearVistaExito("Receta borrado con éxito", $_REQUEST['codigoR']);
		} else {

			crearVistaError("La receta no se pudo borrar", $_REQUEST['codigoR']);
		}

	} elseif ($accion == "Actualizar") {

		require_once "Controlador/updateController.php";

	} elseif ($accion == "Insertar Receta") {

		require_once "Controlador/updateController.php"; //Para aprovechar el código de los métodos, pero como no hay un $_REQUEST['Actualizar'] no da error

		$datosReceta = getDatosReceta_fromRequest();
		$datosIngredientesReceta = getDatosIngredientesReceta_fromRquest();

		$ok = recetaPDO::crearReceta($datosReceta);

		if ($ok) {

			$ok = insertarIngredientes($datosIngredientesReceta);

		}

		if ($ok) {
			crearVistaExito("Receta insertado con éxito", [$datosReceta, $datosIngredientesReceta]);
		} else {
			crearVistaError("La receta no se pudo insertar", [$datosReceta, $datosIngredientesReceta]);
		}

	} else {
		//vista por defecto, al cargar la página de administrador

		$codigo = 10; //el código de receta, por defecto el 10, el primero en órden por nombre

		if (isset($_REQUEST['codigoR'])) {
			$codigo = $_REQUEST['codigoR']; //si recibe un parámetro codigoR se cambia la receta
		}

		$todasRecetas = recetaPDO::verRecetas();

		require_once "Vista/content/crearComboSelReceta.php";
		crearSelReceta($todasRecetas);

		if (isset($_REQUEST['editar'])) {
			$datos = recetaPDO::verReceta($codigo);
			$ingredientes = ingredientes_recetaPDO::verIngredientes_receta($codigo);
			$listIng = ingredientePDO::verIngredientes();

			require_once "Vista/vistaEditarReceta.php";
			crearVistaEditarReceta($datos, $listIng, $ingredientes);

		} else {
			$datos = recetaPDO::verReceta($codigo);
			$ingredientes = ingredientes_recetaPDO::verIngredientes_receta($codigo);

			require_once "Vista/vistaReceta.php";
			crearVistaReceta($datos, $ingredientes);

		}
	}

	crearFooter();

} else {
	require_once "Vista/vistaIniciarSesion.php";
	$mostrarError = true;
	if (!isset($_REQUEST['nombre'])) {
		$mostrarError = false;
	}
	crearVistaIniciarSesion($mostrarError);
}
?>

