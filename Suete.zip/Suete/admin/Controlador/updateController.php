<?php

function getDatosReceta_fromRequest() {

	$NuevoCodR = $_REQUEST['NuevoCodR'];
	$nombre = $_REQUEST['nombre'];
	$descripcion = $_REQUEST['descripcion'];
	$como_se_hace = $_REQUEST['como_se_hace'];
	$imagen = $_REQUEST['imagen'];

	return ["NuevoCodR" => $NuevoCodR, "nombre" => $nombre, "descripcion" => $descripcion, "como_se_hace" => $como_se_hace, "imagen" => $imagen];
}

function getDatosIngredientesReceta_fromRquest() {

	$datosIngredientesReceta = [];

	$ingredientes = $_REQUEST['ingredientes'];
	$cantidadI = $_REQUEST['cantidadI'];

	foreach ($_REQUEST['ingredientes'] as $key => $value) {

		$datosIngredientesReceta[] = ["codI" => $value, "codR" => $_REQUEST['NuevoCodR'], "cantidadI" => $cantidadI[$key]];

	}

	return $datosIngredientesReceta;

}

function insertarIngredientes($datosIngredientesReceta) {

	$ok = ingredientes_recetaPDO::borrarIngredientesReceta($datosIngredientesReceta[0]['codR']);

	if ($ok) {

		foreach ($datosIngredientesReceta as $datos) {

			$ok = ingredientes_recetaPDO::crearIngredientes_receta($datos);

			if (!$ok) {
				break;
			}

		}

	}

	return $ok;
}

if (isset($_REQUEST['accion']) && $_REQUEST['accion'] == "Actualizar") {

	$datosReceta = getDatosReceta_fromRequest();
	$datosIngredientesReceta = getDatosIngredientesReceta_fromRquest();

	$ok = recetaPDO::actualizarReceta($_REQUEST['codR'], $datosReceta);

	if ($ok) {

		$ok = insertarIngredientes($datosIngredientesReceta);

	}

	if ($ok) {
		crearVistaExito("Receta actualizado con éxito", [$datosReceta, $datosIngredientesReceta]);
	} else {
		crearVistaError("La receta no se pudo actualizar", [$datosReceta, $datosIngredientesReceta]);
	}

}

?>