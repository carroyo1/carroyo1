function quitarElementosSelect() {

	var opciones = document.querySelectorAll(".selIngredientes option"); //Al principio ningun select tendra ninguna opción oculta

	for (var i = 0; i < opciones.length; i++) {
		if (opciones[i].value !== "") {
			opciones[i].removeAttribute("hidden");
		}

	}

	var selects = document.getElementsByClassName("selIngredientes"); //con esto ocultamos las opciones si en uno de los selects está elegido

	for (var i = 0; i < selects.length; i++) {

		var ings = document.querySelectorAll(".selIngredientes option[value='"+selects[i].value+"']");

		for (var j = 0; j < ings.length; j++) {

			ings[j].setAttribute("hidden","");

		}

		selects[i].querySelectorAll(".selIngredientes option[value='"+selects[i].value+"']")[0].removeAttribute("hidden");	

	}


}

function borrarIngrediente () {

	var number = this.id.charAt(this.id.length - 1);

	if (document.getElementsByClassName("selIngredientes").length > 1) {

		if (confirm("¿Desea borrar el registro?")) {

			document.getElementById("cont-sel" + number).remove();
			quitarElementosSelect();

		}

	} else {
		alert("Siempre debe haber un ingrediente como mínimo");
	}



}

function crearSelect () {

	var i = document.getElementsByClassName("selIngredientes").length; //Esto sirve para definir la id del div, select y button
	var x = document.createElement("div"); //creamos elementos
	x.className = "cont-selectIngr";
	x.id = "cont-sel" + i;
	x.innerHTML = '<div class="select-content"><select name="ingredientes[]" class="selIngredientes" id="sel' + i + '"></select></div><input type="text" name="cantidadI[]" class="cantIng" placeholder="cantidad"> <button class="borrar-ingr" id="btBorrar' + i + '" type="button">X</button>';

	document.querySelectorAll("#cont-ingredientes")[0].insertBefore(x, document.getElementById("addIngr")); //insertamos un div antes del botón addIngr

	document.getElementById('sel' + i).innerHTML += "<option disabled selected value> -- Selecciona una receta</option>";

	for (var j = 0; j < ingredientes.length; j++) {

		document.getElementById('sel' + i).innerHTML += "<option value = "+ingredientes[j][0]+">"+ingredientes[j][1]+"</option>";

	}

	quitarElementosSelect();

	document.getElementById('sel' + i).addEventListener("change", quitarElementosSelect);

	document.getElementById("btBorrar" + i).addEventListener("click", borrarIngrediente);

}

//cuando se carga el documento:

document.addEventListener('DOMContentLoaded', function () {	

	//Función botón borrar ingrediente
	var btBorrar = document.querySelectorAll(".borrar-ingr");

	for (var i = 0; i < btBorrar.length; i++) {

		btBorrar[i].addEventListener("click", borrarIngrediente);

	}

	quitarElementosSelect(); //primero quitamos los elementos seleccionados en los diferentes select

	//Eventos al cambiar de select

	var selects = document.getElementsByClassName("selIngredientes");

	for (var i = 0; i < selects.length; i++) {

		selects[i].addEventListener("change", quitarElementosSelect); //después añadimos eventos para que no se pueda seleccionar un ingrediente dos veces

	}

	//siempre debe haber algun ingrediente, con esto creamos un select ingrediente al darle a nueva receta. Se podría hacer en html, pero se tendría que duplicar todo el código
	if (document.getElementsByClassName("selIngredientes").length === 0) {
		crearSelect();
	}

	//Función botón añadir ingrediente
	document.getElementById("addIngr").addEventListener("click", crearSelect);

	//Función al cambiar url de foto

	document.getElementById("imagen").addEventListener("input", function () {
		document.querySelectorAll("#cont-imagen img")[0].src = this.value;
	});

	//Para evitar que el formulario se envie sin ingredientes
	document.getElementById("form-receta").addEventListener("submit", function (event) {

		var cont_selects = document.getElementsByClassName("cont-selectIngr");
		var hayIngrediente = true;

		for (var i = 0; i < cont_selects.length && hayIngrediente; i++) {

			if (document.getElementById("sel" + i).value === "") {
				event.preventDefault();
				hayIngrediente = false; 
			}

		}
		if (hayIngrediente && !confirm("¿Desea enviar el formulario?")) {
			event.preventDefault();
			$("#"+this.id).validate().destroy();
		}

	});

	//Para pedir confirmaciones en los links y botones


	//Borrar
	if (document.getElementById("form-borrar") !== null) {
		document.getElementById("form-borrar").addEventListener("submit", function (event) {

			if (confirm("¿Seguro que desea borrar la receta?")) {

				return true;

			} else {

				event.preventDefault();
				return false;

			}

		});
	}

	//Nueva Receta
	if (document.getElementById("form-nuevaR") !== null) {
		document.getElementById("form-nuevaR").addEventListener("submit", function (event) {

			if (!confirm("¿Desea eliminar los cambios e ir a nueva receta?")) {

				event.preventDefault();

			}

		});
	}

	//Para aprovechar css se llama asi, pero se refiere al formulario de DESCARTAR*** cambios
	document.getElementById("form-editar").addEventListener("submit", function (event) {

			if (!confirm("¿Desea descartar los cambios")) {

				event.preventDefault();

			}

	});

	//para controlar que clicando sobre los elementos del menu principal no salimos

	var linksMenu = document.getElementsByClassName("linkTopMenu");

	for (var i = 0; i < linksMenu.length; i++) {

		linksMenu[i].addEventListener("click", function(event){

			if (!confirm("¿Desea eliminar los cambios")) {

				event.preventDefault();

			}
		});
	}

	if (document.getElementById("form-selReceta") !== null) {
	document.getElementById("form-selReceta").addEventListener("submit", function () {

			if (!confirm("¿Desea eliminar los cambios?")) {

				event.preventDefault();

			}

	});
	}

});