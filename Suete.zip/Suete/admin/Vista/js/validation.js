$(function() {
    $('form#form-receta').validate({
        onclick: false,
        /*onfocusout: false,
        onkeyup: false,*/
        rules: {
            NuevoCodR: {
                required: true,
                min: 1,
                remote: {
                    url: "Vista/content/codRNoExiste.php",
                    type: "post",
                    data: {
                        codR: $("#codR").val()
                    }
                }
            },
            "ingredientes[]": {
                required: true
            },
            nombre: {
                maxlength: 100
            },
            imagen: {
                maxlength: 200
            }
        },
        messages: {
            NuevoCodR: {
                required: "Por favor, introduzca un código válido",
                min: "El código no puede ser inferior a 1",
                number: "Debe introducir un número",
                remote: "El código esta en uso, elija un número que este libre"
            },
            "ingredientes[]": {
                required: "Debe elegir un ingrediente"
            },
            nombre: {
                maxlength: "La longitud máxima son 100 caracteres"
            },
            imagen: {
                maxlength: "La longitud máxima son 200 caracteres"
            }
        }
    });
    $('form#form-nuevo-ing').validate({
        rules: {
            nuevoCodI: {
                required: true,
                min: 1,
                remote: {
                    url: "Vista/content/codINoExiste.php",
                    type: "post"
                }
            },
            nombre: {
                maxlength: 40
            },
            imagen: {
                maxlength: 200
            }
        },
        messages: {
            nuevoCodI: {
                required: "Por favor, introduzca un código válido",
                min: "El código no puede ser inferior a 1",
                number: "Debe introducir un número",
                remote: "El código esta en uso, elija un número que este libre"
            },
            nombre: {
                maxlength: "La longitud máxima son 40 caracteres"
            },
            imagen: {
                maxlength: "La longitud máxima son 200 caracteres"
            }
        }
    });
    var formsActu = document.querySelectorAll('.form-actu-ing');
    for (var i = 0; i < formsActu.length; i++) {
        $("#" + formsActu[i].id).validate({
            
            rules: {
                nuevoCodI: {
                    required: true,
                    min: 1,
                    remote: {
                        url: "Vista/content/codINoExiste.php",
                        type: "post",
                        data: {
                            codI: $("#" + formsActu[i].id + " input[name='codI']").val()
                        }
                    }
                },
                nombre: {
                    maxlength: 40
                },
                imagen: {
                    maxlength: 200
                }
            },
            messages: {
                nuevoCodI: {
                    required: "Por favor, introduzca un código válido",
                    min: "El código no puede ser inferior a 1",
                    number: "Debe introducir un número",
                    remote: "El código esta en uso, elija un número que este libre"
                },
                nombre: {
                    maxlength: "La longitud máxima son 40 caracteres"
                },
                imagen: {
                    maxlength: "La longitud máxima son 200 caracteres"
                }
            }
        });
    }
});