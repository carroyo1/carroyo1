function reordenar () {
    event.preventDefault();
    var contsIng = document.getElementsByClassName("cont-form-ing");
    for (var i = contsIng.length - 1; i >= 0; i--) {
        document.getElementsByTagName("section")[0].appendChild(contsIng[i]);
    }

    if (document.getElementsByClassName("arrow")[0].innerHTML == "↓") {
        $("span.arrow").html("&#8593;");
    } else {
        $("span.arrow").html("&#8595;");
    }

}    

document.addEventListener('DOMContentLoaded', function() {

    $("nav#top-menu ul li:last-child").addClass("actual");

    if ($("#form-nuevaR") !== null) {
        $("#form-nuevaR").submit(function(event) {
            if (!confirm("¿Desea borrar los cambios e ir a nueva receta?")) {
                event.preventDefault();
            }
        });
    }
    if ($("#form-editar") !== null) {
        $("#form-editar").submit(function(event) {
            if (!confirm("¿Desea descartar cambios?")) {
                event.preventDefault();
            }
        });
        $("#form-ordenar-123").submit(function (event) {
            if ($("#form-ordenar-123 input[value='123']").attr("class") == "elegido") {
                reordenar();
            }
        });
        $("#form-ordenar-Abc").submit(function (event) {
            if ($("#form-ordenar-Abc input[value='Abc']").attr("class") == "elegido") {
                reordenar();
            }
        });
    }
    var linksMenu = document.getElementsByClassName("linkTopMenu");
    for (var i = 0; i < linksMenu.length; i++) {
        linksMenu[i].addEventListener("click", function(event) {
            if (!confirm("¿Desea eliminar los cambios")) {
                event.preventDefault();
            }
        });
    }
    var formActus = $(".form-actu-ing");
    for (var i = 0; i < formActus.length; i++) {
        formActus[i].addEventListener("submit", function(event) {
            if (!confirm("¿Desea enviar los datos del formulario?")) {
                $("#"+this.id).validate().destroy();
                event.preventDefault();                
            }
        });
    }
    var formBorrars = $(".form-borrar-ing");
    if (formBorrars.length > 0) {
        for (var i = 0; i < formBorrars.length; i++) {
            formBorrars[i].addEventListener("submit", function(event) {
                if (!confirm("¿Desea borrar el ingrediente?")) {
                    event.preventDefault();
                }
            });
        }
    }
    var imgs = $(".imagen");
    for (var i = 0; i < imgs.length; i++) {
        imgs[i].addEventListener("input", function() {
            $("#" + this.getAttribute("for")).attr("src", this.value);
        });
    }
});