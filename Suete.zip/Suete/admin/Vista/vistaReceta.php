<?php function crearVistaReceta($datos, $ingredientes) {?>

<main>

	<div id="container-acciones">

		<form action="index.php" method="get" id="form-nuevaR">
			<input type="submit" value="+ Nueva Receta" name="nuevaR">
		</form>
		<form action="index.php" method="post" id="form-editar">
			<input type="hidden" value="<?php echo $datos['codR'] ?>" name="codigoR">
			<input type="submit" value="Editar" name="editar">
		</form>

		<form action="index.php" method="post" id="form-borrar">
			<input type="hidden" value="<?php echo $datos['codR'] ?>" name="codigoR">
			<input type="submit" value="Borrar" name="accion">
		</form>

	</div>
	<article id="container-cuerpo-receta">
		<h2><?php echo $datos["nombre"] ?></h2>
		<div id="cont-imagen">
			<img src="<?php echo $datos["imagen"] ?>" alt="<?php echo $datos["nombre"] ?>">
		</div>
		<div id="cont-ingredientes">
			<h4>Ingredientes</h4>
			<ul class="listIngredientes">
				<?php foreach ($ingredientes as $value) {?>
					<li>
						<?php echo $value['nombre'] . ": " . $value['cantidad'] ?>
					</li>
				<?php }?>
			</ul>
		</div>
		<div id="cont-descripcion">
		<h4>Descripción</h4>
			<div><?php echo $datos["descripcion"] ?></div>
		</div>
		<div id="cont-como-se-hace">
			<h4>Como se hace</h4>
			<div><?php echo $datos["como_se_hace"] ?></div>
		</div>
	</article>
</main>

<script>
	document.addEventListener('DOMContentLoaded', function () {

		document.getElementById("form-borrar").addEventListener("submit", function (event) {

		if (confirm("¿Seguro que desea borrar la receta?")) {

			return true;

		} else {

			event.preventDefault();
			return false;

		}

	});

});
</script>

<?php }?>