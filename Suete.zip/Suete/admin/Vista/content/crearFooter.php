<?php function crearFooter() {?>

<footer>
	<div class="marca">
		<span>© Suete <?php echo date('Y') ?>. Todos los derechos reservados.</span>
	</div>
</footer>
</body>
</html>

<?php }?>