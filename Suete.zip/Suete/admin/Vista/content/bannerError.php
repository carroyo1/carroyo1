<?php function crearBannerError($mensaje) {?>
	<h5 class="error"><?php echo $mensaje ?></h5>
<?php }?>