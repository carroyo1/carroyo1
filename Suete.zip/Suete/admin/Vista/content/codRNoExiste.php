<?php
if (isset($_REQUEST['NuevoCodR'])) {

	require_once "../../Modelo/connectionPDO.php";
	require_once "../../Modelo/recetaPDO.php";
	session_start();

	if (isset($_REQUEST['codR'])) {

		$codR = $_REQUEST['codR'];

		if (recetaPDO::verReceta($_REQUEST['NuevoCodR']) && $codR != $_REQUEST['NuevoCodR']) {
			echo "false";
		} else {
			echo "true";
		}

	} else {

		if (recetaPDO::verReceta($_REQUEST['NuevoCodR'])) {
			echo "false";
		} else {
			echo "true";
		}

	}

}