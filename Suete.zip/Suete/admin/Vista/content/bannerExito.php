<?php function crearBannerExito($mensaje) {?>
	<h5 class="exito"><?php echo $mensaje ?></h5>
<?php }?>