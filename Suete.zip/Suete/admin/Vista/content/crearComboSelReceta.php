<?php function crearSelReceta($todasRecetas) {
	?>

	<script>

		$("nav#top-menu ul li:first-child").addClass("actual");

	</script>
	<div id="container-selReceta">
		<form action="/Suete/admin/index.php" method="post" id="form-selReceta">
			<select name="codigoR" id="selReceta">
				<?php foreach ($todasRecetas as $registro) {
		?>
					<option value="<?php echo $registro['codR'] ?>" <?php if ($registro['codR'] == $GLOBALS['codigo']) {
			echo "selected";
		}
		?>>

						<?php echo $registro['nombre'] . " - " . $registro['codR'] ?>

					</option>
				<?php }?>
			</select><input type="submit" value="Seleccionar">
		</form>
	</div>

<?php }?>