<?php
if (isset($_REQUEST['nuevoCodI'])) {

	require_once "../../Modelo/connectionPDO.php";
	require_once "../../Modelo/ingredientePDO.php";
	session_start();

	if (isset($_REQUEST['codI'])) {

		$codI = $_REQUEST['codI'];

		if (ingredientePDO::verIngrediente($_REQUEST['nuevoCodI']) && $codI != $_REQUEST['nuevoCodI']) {
			echo "false";
		} else {
			echo "true";
		}

	} else {

		if (ingredientePDO::verIngrediente($_REQUEST['nuevoCodI'])) {
			echo "false";
		} else {
			echo "true";
		}

	}

}