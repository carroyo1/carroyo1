<?php function crearHeader($link) {?>
	<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Seleccionar Ingredientes</title>
	<link rel="shortcut icon" href="../Vista/img/logo.png"/>
	<link rel="stylesheet" href="<?php echo $link ?>">
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
</head>
<body>
	<header>
		<div class="cont-logo-sesion">
			<div class="titulo">
				<figure><img src="../Vista/img/logo.png" alt="Suete"></figure>
				<h1>Administrador</h1>
			</div>
			<div id="sesion">
				<span>Sesión iniciada como</span>
				<span class="user-name"><?php echo $_SESSION['nombre'] ?></span>
				<form action="/Suete/admin"><input type="submit" name="sesion" value="Cerrar Sesión"></form>
			</div>
		</div>
		<nav id="top-menu">
			<ul>
				<li>
					<a class="linkTopMenu" href="/Suete/admin">Ver Recetas</a>
				</li><li>
					<a class="linkTopMenu" href="/Suete/admin?vistaI=vistaI">Ver Ingredientes</a>
				</li>
			</ul>
		</nav>
	</header>
<?php }?>