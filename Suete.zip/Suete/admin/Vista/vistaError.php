<?php function crearVistaError($mensaje, $datos) {?>
	<main>
		<h5 class="error"><?php echo $mensaje ?></h5>
		<?php echo var_dump($datos) ?>
		<a href='index.php' class="linkVolver">Volver</a>
	</main>
<?php }?>
