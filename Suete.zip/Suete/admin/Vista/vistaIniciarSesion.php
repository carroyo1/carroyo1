<?php function crearVistaIniciarSesion($mostrarError) {
	?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Inicar Sesión Suete</title>
	<link rel="shortcut icon" href="../Vista/img/logo.png"/>
	<link rel="stylesheet" href="Vista/css/style.css">
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
	<?php if ($mostrarError) {?>

		<script>
			document.addEventListener('DOMContentLoaded', function() {

				var x = document.createElement("label"); //creamos elementos
				x.className = "error";
				x.innerHTML = 'El usuario o contraseña no son correctos';
				document.querySelectorAll("#cont-nombre")[0].appendChild(x);

				var y = document.createElement("label");
				y.className = "error";
				y.innerHTML = 'El usuario o contraseña no son correctos';
				document.querySelectorAll("#cont-contr")[0].appendChild(y);
				$("input.texto").addClass("error");

			});
		</script>

	<?php }?>
</head>
<body>
	<header>
		<div class="titulo titulo-full-width">
			<figure><img src="../Vista/img/logo.png" alt="Suete"></figure>
			<h1>Administrador</h1>
		</div>
	</header>
	<main>
		<div id="cont-form-iniciar">
			<h2>
				Inicar Sesion
			</h2>
			<form action="index.php" method="post" id="form-iniciar">

				<div id="cont-nombre">
					<input type="text" name="nombre" class="texto" placeholder="Nombre">
				</div>

				<div id="cont-contr">
					<input type="password" name="contr" class="texto" placeholder="Contraseña">
				</div>

				<input type="submit" name="iniciar" value="Iniciar Sesión" id="btIniciar">
			</form>
		</div>
	</main>
	<footer></footer>
</body>
</html>

<?php }?>