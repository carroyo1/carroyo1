<?php function crearVistaNuevaReceta($codR_auto, $listaIng) {
	?>

<main>

	<script>

		 var ingredientes = [];

	<?php for ($i = 0; $i < count($listaIng); $i++) {?>

			ingredientes.push([<?php echo $listaIng[$i]['codI'] ?>, "<?php echo $listaIng[$i]['nombre'] . " " . $listaIng[$i]['codI'] ?>"]);

	<?php }?>

	</script>


	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js">
	        </script>
	<script src="Vista/js/validation.js"></script>
	<script type="text/javascript" src="Vista/js/edit_new.js"></script>


	<article id="container-cuerpo-receta">

		<div id="container-acciones">

			<form action="index.php" method="get" id="form-editar">

				<input type="submit" value="Descartar">

			</form>

		</div>
		<form action="index.php" method="post" id="form-receta" class="form-receta">
			<input type="submit" name="accion" id="btInsertar" class="btAccionReceta" value="Insertar Receta">

			<div id="cont-ideReceta">
				<div id="cont-cod">
					<input type="number" name="NuevoCodR" value="<?php echo $codR_auto ?>" class="texto" min="0" id="NuevocCodR" placeholder="Código">
				</div>
				<div id="cont-nombre">
					<input type="text" name="nombre" value="" class="texto" placeholder="Nombre">
				</div>
			</div>

			<div id="cont-imagen">
				<img src="" alt="Imágen">
				<input type="text" name="imagen" value="" class="texto" id="imagen" placeholder="URL imágen">
			</div>

			<div id="cont-ingredientes">
				<h4>Ingredientes</h4>

				<button id="addIngr" type="button">+</button>

			</div>

			<div id="cont-descripcion">
			<h4>Descripción (HTML)</h4>
				<textarea name="descripcion" class="textoarea"></textarea>
			</div>
			<div id="cont-como-se-hace">
				<h4>Como se hace (HTML)</h4>
				<textarea name="como_se_hace" class="textoarea"></textarea>
			</div>
		</form>

	</article>

</main>

<?php }?>