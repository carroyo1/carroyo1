<?php function crearVistaNuevoIngrediente($codI_auto) {
	?>

<main>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js">
	        </script>
	<script src="Vista/js/validation.js"></script>
	<script type="text/javascript" src="Vista/js/edit_newIngrediente.js"></script>

	<div id="container-acciones">

		<form action="index.php" method="get" id="form-editar">

			<input type="submit" value="Descartar">
			<input type="hidden" name="vistaI" value="vistaI">

		</form>

	</div>

	<section>

			<div class="cont-form-ing" id="cont-form-nuevo-ing">

				<form action="index.php" method="post" id='form-nuevo-ing' class="form-actu-ing">
					<figure>
						<img src="" alt="foto" class="form-ing-img" id="form-ing-img0">
					</figure>
					<input type="hidden" value="+ Nuevo Ingrediente" name="nuevoI">
					<input type="hidden" name="vistaI" value="vistaI">
					<div class="cont-codI">
						<input type="number" value="<?php echo "$codI_auto"; ?>" name="nuevoCodI" min=0 class="textoIngr nuevoCodI" placeholder="Código">
					</div>
					<div class="cont-nombre">
						<input type="text" value="" name="nombre" class="textoIngr nombre" placeholder="Nombre">
					</div>
					<div class="cont-imagen">
						<input type="text" value="" name="imagen" class="textoIngr imagen" for="form-ing-img0" placeholder="URL imágen">
					</div>
					<input type="submit" name="accion" value="Insertar" class="btActuIngr">

				</form>

			</div>

	</section>

</main>

<?php }
?>
