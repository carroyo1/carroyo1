<?php function crearVistaEditarReceta($datos, $listaIng, $ingredientes) {
	?>

<main>

	<script>

		 var ingredientes = [];


	<?php for ($i = 0; $i < count($listaIng); $i++) {?>

			ingredientes.push([<?php echo $listaIng[$i]['codI'] ?>, "<?php echo $listaIng[$i]['nombre'] . " " . $listaIng[$i]['codI'] ?>"]);

	<?php }?>

	</script>

	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js">
	</script>
	<script src="Vista/js/validation.js"></script>
	<script type="text/javascript" src="Vista/js/edit_new.js"></script>


	<div id="container-acciones">

		<form action="index.php" method="get" id="form-nuevaR">
			<input type="submit" value="+ Nueva Receta" name="nuevaR">
		</form>
		<form action="index.php" method="post" id="form-editar">
			<input type="hidden" value="<?php echo $datos['codR'] ?>" name="codigoR">
			<input type="submit" value="Descartar">
		</form>
		<form action="index.php" method="post" id="form-borrar">
			<input type="hidden" value="<?php echo $datos['codR'] ?>" name="codigoR">
			<input type="submit" value="Borrar" name="accion">
		</form>

	</div>
	<article id="container-cuerpo-receta">

		<form action="index.php" method="post" id="form-receta" class="form-receta">
			<input type="submit" name="accion" id="btActualizar" value="Actualizar">

			<div id="cont-ideReceta">
				<div id="cont-cod">
					<input type="number" name="NuevoCodR" value="<?php echo $datos['codR'] ?>" class="texto" min="1" id="NuevocCodR">
					<input type="hidden" name="codR" value="<?php echo $datos['codR'] ?>" class="texto" id="codR">
				</div>
				<div id="cont-nombre">
					<input type="text" name="nombre" value="<?php echo $datos["nombre"] ?>" class="texto">
				</div>
			</div>

			<div id="cont-imagen">
				<img src="<?php echo $datos["imagen"] ?>" alt="<?php echo $datos["nombre"] ?>">
				<input type="text" name="imagen" value="<?php echo $datos["imagen"] ?>" class="texto" id="imagen">
			</div>

			<div id="cont-ingredientes">
				<h4>Ingredientes</h4>

				<?php foreach ($ingredientes as $keySel => $ingrediente) {
		?>
					<div class="cont-selectIngr" id="<?php echo "cont-sel" . $keySel ?>">

						<div class="select-content">

						<select name="ingredientes[]" class="selIngredientes" id="<?php echo "sel" . $keySel ?>">

							<?php for ($i = 0; $i < count($listaIng); $i++) {
			?>

								<option value="<?php echo $listaIng[$i]['codI'] ?>" <?php if ($ingrediente['codI'] == $listaIng[$i]['codI']) {
				echo "selected";
			}
			?>><?php echo $listaIng[$i]['nombre'] . " " . $listaIng[$i]['codI'] ?></option>

							<?php }?>

						</select></div><input type="text" name="cantidadI[]" class="cantIng" value="<?php echo $ingrediente['cantidad'] ?>">
						<button class="borrar-ingr" id="<?php echo "btBorrar" . $keySel ?>" type="button">X</button>
					</div>

				<?php }?>

				<button id="addIngr" type="button">+</button>

			</div>

			<div id="cont-descripcion">
			<h4>Descripción (HTML)</h4>
				<textarea name="descripcion" class="textoarea"><?php echo $datos["descripcion"] ?></textarea>
			</div>
			<div id="cont-como-se-hace">
				<h4>Como se hace (HTML)</h4>
				<textarea name="como_se_hace" class="textoarea"><?php echo $datos["como_se_hace"] ?></textarea>
			</div>
		</form>

	</article>

</main>

<?php }?>