<?php function crearVistaIngrediente($listaIng) {
	?>

<main>

	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js">
	        </script>
	<script src="Vista/js/validation.js"></script>
	<script type="text/javascript" src="Vista/js/edit_newIngrediente.js"></script>

	<div id="container-acciones">

		<form action="index.php" method="get" id="form-nuevaR">

			<input type="submit" value="+ Nuevo Ingrediente" name="nuevoI">
			<input type="hidden" name="vistaI" value="vistaI">

		</form>

		<span style="margin-left: 10px">Ordenar</span>

		<form action="index.php" method="get" class="form-ordenar" id="form-ordenar-123">
			<?php if (isset($_REQUEST['ordenar']) && $_REQUEST['ordenar'] == "123") {?>

				<span class="arrow">&#8595;</span>

			<?php }?>

			<input type="submit" value="123" name="ordenar" <?php if (isset($_REQUEST['ordenar']) && $_REQUEST['ordenar'] == "123") {
		echo "class = 'elegido'";
	}
	?>><input type="hidden" name="vistaI" value="vistaI">

		</form>

		<form action="index.php" method="get" class="form-ordenar" id="form-ordenar-Abc">

			<?php if (isset($_REQUEST['ordenar']) && $_REQUEST['ordenar'] == "Abc") {?>

				<span class="arrow">&#8595;</span>

			<?php }?>

			<input type="submit" value="Abc" name="ordenar" <?php if (isset($_REQUEST['ordenar']) && $_REQUEST['ordenar'] == "Abc") {
		echo "class = 'elegido'";
	}
	?>><input type="hidden" name="vistaI" value="vistaI">

		</form>

	</div>

	<section>

		<?php foreach ($listaIng as $key => $value) {?>

			<div class="cont-form-ing" id="<?php echo "cont-form-ing$key"; ?>">

				<form action="index.php" method="post" id='<?php echo "form-actu-ing$key"; ?>' class="form-actu-ing">
					<figure>
						<img src="<?php echo "$value[imagen]"; ?>" alt="<?php echo "$value[nombre]"; ?>" class="form-ing-img" id="<?php echo "form-ing-img$value[codI]"; ?>">
					</figure>
					<div class="cont-codI">
						<input type="hidden" value="<?php echo "$value[codI]"; ?>" name="codI">
						<input type="number" value="<?php echo "$value[codI]"; ?>" name="nuevoCodI" min=0 class="textoIngr nuevoCodI">
					</div>
					<div class="cont-nombre">
						<input type="text" value="<?php echo "$value[nombre]"; ?>" name="nombre" class="textoIngr nombre">
					</div>
					<div class="cont-imagen">
					<input type="text" value="<?php echo "$value[imagen]"; ?>" name="imagen" class="textoIngr imagen" for="<?php echo "form-ing-img$value[codI]"; ?>">
					</div>
					<input type="hidden" name="vistaI" value="vistaI">
					<input type="submit" name="accion" value="Actualizar" class="btActuIngr">

				</form>

				<form action="index.php" method="post" id='<?php echo "form-borrar-ing$key"; ?>' class="form-borrar-ing">

					<input type="submit" name="accion" value="Borrar" class="btBorrarIngr">
					<input type="hidden" value="<?php echo "$value[codI]"; ?>" name="codI">
					<input type="hidden" name="vistaI" value="vistaI">

				</form>

			</div>

		<?php }?>

	</section>

</main>

<?php }
?>
